insert into tb_autores(autor_id, nome, pais) values(1, 'Pedro', 'Brasil');
insert into tb_autores(autor_id, nome, pais) values(2, 'Carlos', 'Argentina');
insert into tb_autores(autor_id, nome, pais) values(3, 'Rodrigo', 'Brasil');
insert into tb_autores(autor_id, nome, pais) values(4, 'Sandra', 'Alemanha');
insert into tb_autores(autor_id, nome, pais) values(5, 'Joao', 'Porto Rico');
insert into tb_autores(autor_id, nome, pais) values(6, 'Francisco', 'Espanha');

insert into tb_editoras(editora_id, nome, cidade) values(1, 'Campus', 'Rio de Janeiro');
insert into tb_editoras(editora_id, nome, cidade) values(2, 'Saraiva', 'São Paulo');
insert into tb_editoras(editora_id, nome, cidade) values(3, 'Moderna', 'Rio de Janeiro');
insert into tb_editoras(editora_id, nome, cidade) values(4, 'Bookman', 'Florianópolis');
insert into tb_editoras(editora_id, nome, cidade) values(5, 'Atlas', 'Porto Alegre');
insert into tb_editoras(editora_id, nome, cidade) values(6, 'Pearson', 'São Paulo');


insert into tb_livros(livro_id, titulo, data_publicacao, numero_paginas, preco) values (1,'Sobre Mouses e Homens', '1954-11-08', 100, 11.00);
insert into tb_livros(livro_id, titulo, data_publicacao, numero_paginas, preco) values (2,'Um Estranho no Ninho', '1973-11-08', 200, 15.00);
insert into tb_livros(livro_id, titulo, data_publicacao, numero_paginas, preco) values (3,'Por Quem os Sinos Dobram', '1932-11-08', 100, 13.00);
insert into tb_livros(livro_id, titulo, data_publicacao, numero_paginas, preco) values (4,'Guerra e Paz', '1955-11-08', 140, 15.00);
insert into tb_livros(livro_id, titulo, data_publicacao, numero_paginas, preco) values (5,'As Vinhas da Ira', '1955-11-08', 300, 16.00);
insert into tb_livros(livro_id, titulo, data_publicacao, numero_paginas, preco) values (6,'Padrões de Design', '1996-11-08', 180, 14.00);
insert into tb_livros(livro_id, titulo, data_publicacao, numero_paginas, preco) values (7,'Um Conto de Duas Cidades', '1943-11-08', 400, 15.00);

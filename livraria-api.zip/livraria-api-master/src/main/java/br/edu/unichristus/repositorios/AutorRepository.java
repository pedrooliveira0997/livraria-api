package br.edu.unichristus.repositorios;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.unichristus.entidades.Autor;

public interface AutorRepository extends JpaRepository<Autor, Long> {

	public Autor findByNome(String nome);

	public List<Autor> findByPais(String pais);
}

package br.edu.unichristus;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import br.edu.unichristus.entidades.Editora;
import br.edu.unichristus.entidades.Livro;
import br.edu.unichristus.entidades.Autor;
import br.edu.unichristus.servicos.AutorService;
import br.edu.unichristus.servicos.EditoraService;
import br.edu.unichristus.servicos.LivroService;


@SpringBootApplication
public class LivrariaApiApplication implements CommandLineRunner {

	@Autowired
	private LivroService servicoLivros;

	@Autowired
	private EditoraService servicoEditoras;
	
	@Autowired
	private AutorService servicoAutores;

	@Override
	public void run(String... args) {
		Livro livro = new Livro("Java Como Programar", LocalDate.of(2017, 8, 20), 250, new BigDecimal("15.00"));
		this.servicoLivros.salvar(livro);

		// Buscando um livro pelo seu ID
		Livro livro1 = this.servicoLivros.buscarPeloID(1L);
		System.out.println(livro1);

		// Buscando vários livros pelos seus IDs (1, 3 e 5)
		@SuppressWarnings("serial")
		List<Livro> livros2 = this.servicoLivros.buscarPelosIDs(new ArrayList<Long>() {
			{
				add(1L);
				add(3L);
				add(5L);
			}
		});
		livros2.forEach(System.out::println);

		// Alterando o título do livro com o ID 1
		Livro livro3 = this.servicoLivros.buscarPeloID(1L);
		System.out.println(livro3);
		livro3.setTitulo("Pro Spring");
		this.servicoLivros.salvar(livro3);
		System.out.println(livro3);

		// Removendo dois livros
		this.servicoLivros.remover(1L);
		this.servicoLivros.remover(this.servicoLivros.buscarPeloID(2L));

		// CONSULTAS DERIVADAS

		// Busca um livro com o título Guerra e Paz
		Livro livro5 = this.servicoLivros.buscarPeloTitulo("Guerra e Paz");
		System.out.println(livro5);

		// Busca livros contendo a palavra "de" no seu título
		List<Livro> livros6 = this.servicoLivros.buscarPeloTituloLike("%de%");
		livros6.forEach(System.out::println);

		// Busca livros contendo a palavra "de" no seu título (sem máscara)
		this.servicoLivros.buscarPeloTituloContendo("de").forEach(System.out::println);

		// Busca livros cujo título comece com "Um"
		this.servicoLivros.buscarPeloTituloComecandoCom("Um").forEach(System.out::println);

		// Busca títulos com o título "Guerra e Paz", independente da capitalização
		this.servicoLivros.buscarPeloTituloIgnorandoCaixa("GUERRA E PAZ").forEach(System.out::println);

		// Busca os livros com exatamente 300 páginas
		this.servicoLivros.buscarPeloNumeroDePaginas(300).forEach(System.out::println);

		// Busca livros com mais de 300 páginas
		this.servicoLivros.buscarPeloNumeroDePaginasMaiorQue(300).forEach(System.out::println);

		// Busca os livros contendo entre 170 e 300 páginas
		this.servicoLivros.buscarPeloNumeroDePaginasIntervalo(170, 300).forEach(System.out::println);

		// Busca os livros com título contendo as palavras "de" ou "um"
		this.servicoLivros.buscarPeloTituloContendoOu("de", "um").forEach(System.out::println);

		// Busca os livros cujo título não seja "Guerra e Paz"
		this.servicoLivros.buscarPeloTituloDiferenteDe("Guerra e Paz").forEach(System.out::println);

		// Busca os livros contendo a palavra "de" no seu título e que tenham mais de
		// 200 páginas
		this.servicoLivros.buscarPeloTituloContendoENumeroDePaginasMaiorQue("de", 200).forEach(System.out::println);

		// Busca livros publicados após 1 de janeiro de 1995
		this.servicoLivros.buscarPorDataPublicacaoDepoisDe(LocalDate.of(1995, 01, 01)).forEach(System.out::println);

		// Busca livros publicados antes de 31 de dezembro de 1972
		this.servicoLivros.buscarPorDataPublicacaoAntesDe(LocalDate.of(1972, 12, 31)).forEach(System.out::println);

		// Busca livros publicados entre 1 de janeiro de 1943 e 15 de novembro de 1955
		this.servicoLivros.buscarPorDataPublicacaoEntre(LocalDate.of(1943, 01, 01), LocalDate.of(1955, 11, 15))
				.forEach(System.out::println);

		// Gravar um nova editora
		this.servicoEditoras.salvar(new Editora("FTD", "Juazeiro do Norte"));

//		Alterar a cidade da editora Bookman para Porto Alegre
		Editora bookman = this.servicoEditoras.buscarPeloNome("Bookman");
		System.out.println(bookman);
		bookman.setCidade("Porto Alegre");
		this.servicoEditoras.salvar(bookman);
		System.out.println(bookman);
		System.out.println();

//		Remover a editora Moderna
		this.servicoEditoras.remover(this.servicoEditoras.buscarPeloNome("Moderna"));

//		Buscar as editoras com sede no Rio de Janeiro
		this.servicoEditoras.buscarPelaCidade("Porto Alegre").forEach(System.out::println);
		System.out.println();

//		Buscar as editoras cujo nome inicie pelas letras ‘A’ ou ‘B’
		this.servicoEditoras.buscarPeloNomeIniciandoEmAouB("A", "B").forEach(System.out::println);
		System.out.println();
		
//		Buscar as editoras do Rio de Janeiro e de São Paulo
		this.servicoEditoras.buscarPelasCidadesAouB("Rio de Janeiro", "São Paulo").forEach(System.out::println);
//		Salvando novo autor
		Autor autor1 = this.servicoAutores.buscarPeloNomedoAutor("Carlos");
		System.out.println(autor1);
//		Buscar pelo pais
		this.servicoAutores.buscarPeloPais("Brasil").forEach(System.out::println);
		System.out.println();
		
		
		
		
	}

	public static void main(String[] args) {
		SpringApplication.run(LivrariaApiApplication.class, args);
	}

	//public AutorService getServicoAutores() {
	//	return servicoAutores;
	//}

	//public void setServicoAutores(AutorService servicoAutores) {
	//	this.servicoAutores = servicoAutores;
	//}
}

package br.edu.unichristus.servicos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.unichristus.entidades.Autor;
import br.edu.unichristus.repositorios.AutorRepository;

@Service
public class AutorService {
	
	@Autowired
	private AutorRepository repo;
	
	public void salvarAutor(Autor autor) {
		this.repo.save(autor);
	}
	
	public Autor buscarPeloNomedoAutor(String nome) {
		return this.repo.findByNome(nome);
	}
	
	public List<Autor> buscarPeloPais(String pais) {
		return this.repo.findByPais(pais);
	}
	//public List<Editora> buscarTodas() {
	//	return this.repo.findAll();
	//}
	
	//public void remover(Editora editora) {
	//	this.repo.delete(editora);
	//}
	
	//public List<Editora> buscarPelaCidade(String cidade) {
	//	return this.repo.findByCidade(cidade);
	//}
	
	//public List<Editora> buscarPeloNomeIniciandoEmAouB(String a, String b) {
	//	return this.repo.findByNomeStartingWithOrNomeStartingWith(a, b);
	//}
	
	//public List<Editora> buscarPelasCidadesAouB(String cidade1, String cidade2) {
	//	return this.repo.findByCidadeEqualsOrCidadeEquals(cidade1, cidade2);
	//}

}

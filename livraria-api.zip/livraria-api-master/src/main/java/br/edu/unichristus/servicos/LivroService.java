package br.edu.unichristus.servicos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.unichristus.entidades.Livro;
import br.edu.unichristus.repositorios.LivroRepository;

@Service
public class LivroService {
	@Autowired
	private LivroRepository repo;

	/**
	 * Grava um novo livro
	 * 
	 * @param livro
	 */
	public void salvar(Livro livro) {
		this.repo.save(livro);
	}

	/**
	 * Busca um livro pelo seu ID
	 * 
	 * @param idLivro
	 * @return
	 */
	public Livro buscarPeloID(long idLivro) {
		return this.repo.findById(idLivro).get();
	}

	/**
	 * Busca os livros cujos IDs correspondem aos informados
	 * 
	 * @param idsLivros
	 * @return
	 */
	public List<Livro> buscarPelosIDs(ArrayList<Long> idsLivros) {
		return this.repo.findAllById(idsLivros);
	}

	/**
	 * Remove um livro pelo seu ID
	 * 
	 * @param idLivro
	 */
	public void remover(Long idLivro) {
		this.repo.deleteById(idLivro);
	}

	/**
	 * Remove um livro
	 * 
	 * @param livro
	 */
	public void remover(Livro livro) {
		this.repo.delete(livro);
	}

	/**
	 * Busca um Livro pelo seu título
	 * 
	 * @param titulo
	 * @return
	 */
	public Livro buscarPeloTitulo(String titulo) {
		return this.repo.findByTitulo(titulo);
	}

	/**
	 * Busca livros pelo seu título, usando uma máscara
	 * 
	 * @param titulo
	 * @return
	 */
	public List<Livro> buscarPeloTituloLike(String titulo) {
		return this.repo.findByTituloLike(titulo);
	}

	/**
	 * Busca livros contendo a string informada (sem uso de máscaras)
	 * 
	 * @param titulo
	 * @return
	 */
	public List<Livro> buscarPeloTituloContendo(String titulo) {
		return this.repo.findByTituloContaining(titulo);
	}

	/**
	 * Busca livros cujo título inicia pela string informada
	 * 
	 * @param titulo
	 * @return
	 */
	public List<Livro> buscarPeloTituloComecandoCom(String titulo) {
		return this.repo.findByTituloStartingWith(titulo);
	}

	/**
	 * Busca os livros cujo título termina com a string informada
	 * 
	 * @param titulo
	 * @return
	 */
	public List<Livro> buscarPeloTituloTerminandoCom(String titulo) {
		return this.repo.findByTituloEndingWith(titulo);
	}

	/**
	 * Busca livros pelo seu título, ignorando a capitalização do parâmetro
	 * 
	 * @param titulo
	 * @return
	 */
	public List<Livro> buscarPeloTituloIgnorandoCaixa(String titulo) {
		return this.repo.findByTituloIgnoreCase(titulo);
	}

	/**
	 * Busca os livros que contenham exatamente o número de páginas informado
	 * 
	 * @param numeroPaginas
	 * @return
	 */
	public List<Livro> buscarPeloNumeroDePaginas(int numeroPaginas) {
		return this.repo.findByNumeroPaginasEquals(numeroPaginas);
	}

	/**
	 * Busca os livros que contenham um número de páginas maior que o informado
	 * 
	 * @param numeroPaginas
	 * @return
	 */
	public List<Livro> buscarPeloNumeroDePaginasMaiorQue(int numeroPaginas) {
		return this.repo.findByNumeroPaginasGreaterThan(numeroPaginas);
	}

	/**
	 * Busca os livros que contenham o número de páginas dentro do intervalo
	 * informado
	 * 
	 * @param min
	 * @param max
	 * @return
	 */
	public List<Livro> buscarPeloNumeroDePaginasIntervalo(int min, int max) {
		return this.repo.findByNumeroPaginasBetween(min, max);
	}

	/**
	 * Busca os livros que contenham no seu título pelo menos uma das strings
	 * informadas
	 * 
	 * @param titulo1
	 * @param titulo2
	 * @return
	 */
	public List<Livro> buscarPeloTituloContendoOu(String titulo1, String titulo2) {
		return this.repo.findByTituloContainingOrTituloContaining(titulo1, titulo2);
	}

	/**
	 * Busca os livros cujo título não contenha a string informada
	 * 
	 * @param titulo
	 * @return
	 */
	public List<Livro> buscarPeloTituloDiferenteDe(String titulo) {
		return this.repo.findByTituloNot(titulo);
	}

	/**
	 * Busca os livros cujo título contenha a string informada e cujo número de
	 * páginas seja maior que o informado
	 * 
	 * @param titulo
	 * @param numeroPaginas
	 * @return
	 */
	public List<Livro> buscarPeloTituloContendoENumeroDePaginasMaiorQue(String titulo, int numeroPaginas) {
		return this.repo.findByTituloContainingAndNumeroPaginasGreaterThan(titulo, numeroPaginas);
	}

	/**
	 * Busca os livros cujo data de publicação seja posterior à data informada
	 * 
	 * @param dataPublicacao
	 * @return
	 */
	public List<Livro> buscarPorDataPublicacaoDepoisDe(LocalDate dataPublicacao) {
		return this.repo.findByDataPublicacaoAfter(dataPublicacao);
	}

	/**
	 * Busca os livros cuja data de publicação seja anterior à data informada
	 * 
	 * @param dataPublicacao
	 * @return
	 */
	public List<Livro> buscarPorDataPublicacaoAntesDe(LocalDate dataPublicacao) {
		return this.repo.findByDataPublicacaoBefore(dataPublicacao);
	}

	/**
	 * Busca os livros cuja data de publicação esteja entre as datas informadas
	 * 
	 * @param dataPublicacao1
	 * @param dataPublicacao2
	 * @return
	 */
	public List<Livro> buscarPorDataPublicacaoEntre(LocalDate dataPublicacao1, LocalDate dataPublicacao2) {
		return this.repo.findByDataPublicacaoBetween(dataPublicacao1, dataPublicacao2);
	}

}

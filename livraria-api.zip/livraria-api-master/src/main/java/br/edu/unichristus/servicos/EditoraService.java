package br.edu.unichristus.servicos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.unichristus.entidades.Editora;
import br.edu.unichristus.repositorios.EditoraRepository;

@Service
public class EditoraService {
	
	@Autowired
	private EditoraRepository repo;
	
	public void salvar(Editora editora) {
		this.repo.save(editora);
	}
	
	public Editora buscarPeloNome(String nome) {
		return this.repo.findByNome(nome);
	}
	
	public List<Editora> buscarTodas() {
		return this.repo.findAll();
	}
	
	public void remover(Editora editora) {
		this.repo.delete(editora);
	}
	
	public List<Editora> buscarPelaCidade(String cidade) {
		return this.repo.findByCidade(cidade);
	}
	
	public List<Editora> buscarPeloNomeIniciandoEmAouB(String a, String b) {
		return this.repo.findByNomeStartingWithOrNomeStartingWith(a, b);
	}
	
	public List<Editora> buscarPelasCidadesAouB(String cidade1, String cidade2) {
		return this.repo.findByCidadeEqualsOrCidadeEquals(cidade1, cidade2);
	}

}
